select * from newtable.address;
